import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';

ReactDOM.render(<App />, document.getElementById('root'));


// Createing a stand alone element
// import HijriDatePickerElement from '../lib/components/HijriDatePickerElement'
// export default HijriDatePickerElement;
